#!/bin/bash
annees=("2016" "2017" "2018")
for annee in annees; do
    ./argument_entites.sh $1 $2
done
