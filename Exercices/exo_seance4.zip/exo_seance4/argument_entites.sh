#!/usr/bin/env bash
# Écrire un script qui compte les entités pour une année un type d’entité donnés en argument du programme.

echo " Pour l'année $1 : " #>> sortie.txt 
cat ./ann/$1/*/* | grep $2 | wc -l #>> sortie.txt 
