#!/bin/bash
#créer un script pour établir le classement des lieux les plus cités.

cat ./ann/$1/$2/*  | sort | uniq -c | sort -nr | head -n$3